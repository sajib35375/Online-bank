const minus = document.getElementById("minus");
minus.addEventListener("click",function(){
    console.log(minus);
})